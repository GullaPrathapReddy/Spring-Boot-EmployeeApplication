package com.pt.sb.SpringBootEmployeeAplplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootEmployeeAplplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootEmployeeAplplicationApplication.class, args);
	}

}
